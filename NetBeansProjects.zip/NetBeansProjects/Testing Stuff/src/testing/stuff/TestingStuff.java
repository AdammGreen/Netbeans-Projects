package testing.stuff;

import javax.swing.JOptionPane;

public class TestingStuff {
    public static void main(String[] args) 
    {
        String test = JOptionPane.showInputDialog("Please enter a string");
        
        for(int i = 0; i < test.length(); i++)
        {
            System.out.println(test.charAt(i));
        }
    }
    
}
