/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package martialcombatapp;

import javax.swing.JOptionPane;

/**
 *
 * @author adamdanielgreen
 */
public class MartialCombatApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Player Adam = new Player();

        int option = (int) Integer.parseInt(JOptionPane.showInputDialog("Press 1 to Fight a training dummy. 2 to Fight a Monster. 3 to Quit "));

        while (Adam.isDead() == false && option != 3) {

            int decision = (int) Integer.parseInt(JOptionPane.showInputDialog("Press 1 to Attack. 2 to heal. 3 to Run Away "));

            if (decision == 1) {
                Adam.playerAttack();

            }
            if (decision == 2) {
                Adam.heal();

            }
            if (decision == 3) {
                Adam.runAway();

            }
        }

        if (Adam.isDead() == false && Adam.hasTarget() == false) {
            int option2 = (int) Integer.parseInt(JOptionPane.showInputDialog("Press 1 to Fight a training dummy. 2 to Fight a Monster. 3 to Quit "));

            if (Adam.isDead() == true || option == 3 || option2 == 3) {
                System.out.println("Game Over!");
            }

        }
    }
}
