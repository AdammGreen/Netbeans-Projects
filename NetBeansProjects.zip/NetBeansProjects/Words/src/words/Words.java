/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package words;

import javax.swing.JOptionPane;

/**
 *
 * @author adamdanielgreen
 */
public class Words {

    /**
     * @param args the command line arguments
     * @return 
     */
    public static void main(String[] args) {
    
        
       
        
        String word = JOptionPane.showInputDialog("Enter a 3 letter word");
       
        if(word.length() == 3){
       
            System.out.print(word);
        
        
        }
       }
    }
     


