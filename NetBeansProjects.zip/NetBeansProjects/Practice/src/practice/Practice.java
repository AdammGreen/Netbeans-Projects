/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practice;

import java.util.Scanner;

/**
 *
 * @author adamdanielgreen
 */
public class Practice {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String line = "hello 45 65.9 true";
        
        Scanner scLine = new Scanner (line);
        String greet = scLine.next();
        int num = scLine.nextInt();
        double real = scLine.nextDouble();
        boolean ans = scLine.nextBoolean();
        scLine.close();
        System.out.println(greet + " " + num + " " + real + " " + " " + ans);
    }
    
}
