/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package textfilescanner;

import java.util.Scanner;

/**
 *
 * @author adamdanielgreen
 */
public class TextfileScanner {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      
    private Log logArr[] = new Log[200];
    private int size = 0;

    public LogArray() {

        try {
            Scanner scFile = new Scanner(new File("logs.txt"));

            while (scFile.hasNextLine()) {
                String line = scFile.nextLine();

                Scanner scLine = new Scanner(line).useDelimiter("#");

                String name = scLine.next();
                String email = scLine.next();
                int total = scLine.nextInt();

                logArr[size] = new Log(name, email, total);
                size++
                       
            }
            scFile.close();
        }
    catch (Exception e){
        System.out.println("File npt found");
    }
    }
}

}
