/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examtesting;

/**
 *
 * @author adamdanielgreen
 */
public class Examtesting {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     char x =97;
     System.out.println(x);
     String name = "john";
     System.out.println(name.charAt(3));
     System.out.println(name.length());
     int a = 4;
     double b = -4;
     System.out.println(Math.pow(a, 2));
     System.out.println(Math.sqrt(a));
     System.out.println(Math.random());
     System.out.println(Math.abs(b));
    }
    
}
