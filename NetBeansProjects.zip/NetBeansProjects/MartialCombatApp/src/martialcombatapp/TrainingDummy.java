/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package martialcombatapp;

/**
 *
 * @author adamdanielgreen
 */
public class TrainingDummy {
 
    private int attackRating;
    private int defenseRating;

    public TrainingDummy() {
        this.attackRating = (int) (Math.random() * (15 - 5) + 5);
        this.defenseRating = (int)(Math.random() * (15 - 5) + 5);
        System.out.println(this.getClass().getSimpleName() + "TrainingDummy created with"+ attackRating + "attack and" + defenseRating + "defense");
    }
 
    public boolean recieveAttack(int attackStrength){
        if(attackStrength > defenseRating){
            System.out.println("Ouch!That Hurt");   
        }
        else{
            System.out.println("Tis barely a scratch" );
        }
    return false;
    }

    public int getAttackRating() {
        return attackRating;
    }

    public int getDefenseRating() {
        return defenseRating;
    }
   
    



}