/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package martialcombatapp;

/**
 *
 * @author adamdanielgreen
 */
public class Player extends Monster {

    private TrainingDummy target;
    private boolean died;

    public Player() {
        this.died = false;
    }

    public void setTarget(TrainingDummy jeff) {
        this.target = jeff;
    }

    public boolean playerAttack() {

        if (this.makeAttack(target) == true) {
            this.target = null;
        } 
        else if (this.target instanceof Monster) {
            target.recieveAttack(this.getAttackRating());
        }
        if (health < 0) {
            return true;
        }

        return false;

    }

    public void heal() {

        int heal = (int) (Math.random() * (5 - 1) + 1);
        this.health = this.health + heal;

        System.out.println("Player healed up by " + heal + "curent health is " + this.health);

        if (this.target instanceof Monster) {
            target.recieveAttack(this.getAttackRating());
        }
        if (health < 0) {
            died = true;

        }

    }

    public boolean isDead() {
        return died;
    }

    public void runAway() {

        if (this.target instanceof Monster) {
            this.recieveAttack(this.getAttackRating());

            if (health < 0) {
                died = true;

            }
            this.target = null;
        }
    }

    public boolean hasTarget() {
        if (this.target == null) {
            return false;
        }
        return true;

    }

}
