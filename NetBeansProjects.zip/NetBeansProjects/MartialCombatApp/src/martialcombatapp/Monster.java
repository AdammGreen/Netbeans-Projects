/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package martialcombatapp;

/**
 *
 * @author adamdanielgreen
 */
public class Monster extends TrainingDummy {

    protected int health;

    public Monster() {
        this.health = (int) (Math.random() * (40 - 20) + 20);
        System.out.println("Health is " + health);
    }

    @Override
    public boolean recieveAttack(int attackStrength) {
        if (attackStrength > this.getDefenseRating()) {

            health = (int) (health - (attackStrength - this.getDefenseRating()));

            System.out.println(this.getClass().getSimpleName() + "Monster was damaged for " + this.recieveAttack(attackStrength) + " health ,current health is " + health);

            if (health < 0) {
                System.out.println("Monster died");
                return true;
            }        

        }

        return false;

    }

    public boolean makeAttack(TrainingDummy jeff) {

        if (jeff.recieveAttack(this.getAttackRating())) {
            return true;
        } else {
            return false;
        }
    }

    public int getHealth() {
        return health;
    }

    @Override
    public String toString() {
        return "monsters health is " + health + " attack damage is " + this.getAttackRating() + " defense rating is " + this.getDefenseRating();
    }
}
