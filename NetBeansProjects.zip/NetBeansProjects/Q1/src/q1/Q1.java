/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package q1;

import javax.swing.JOptionPane;

/**
 *
 * @author adamdanielgreen
 */
public class Q1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    
    int count = 0;
    
    String string= JOptionPane.showInputDialog("Enter a word");
    System.out.println(string+",amount of characters ="+(int)string.length());
    
    for(int i = 0; i < string.length();i++){
     
        char ch = string.charAt(i);
        if
                (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' || ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U') {
                System.out.println("a vowel is " + ch);
                count++;
             
    }
    


    }
    System.out.println("Number of vowels : " + count);

}
}