/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sort;

/**
 *
 * @author adamdanielgreen
 */
public class Sort {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    
        public void sort(){
        for(int i = 0; i < size-1; i++)
            for(int j = i + 1; j < size; j++);
        (logArr[i].getSurname.compareTo(LogArr[j].surname)>0){
            log temp = logArr[i];
            logArr[i]=LogArr[j];
            logArr[j]=temp;
            
        }
    }
    
}
