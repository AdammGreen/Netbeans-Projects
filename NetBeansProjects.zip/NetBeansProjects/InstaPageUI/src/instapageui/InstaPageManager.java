/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package instapageui;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author adamdanielgreen
 */
public class InstaPageManager {

    private Post[] post = new Post[100];
    private Response[] response = new Response[500];

    private int countPost = 0;
    private int countResponse = 0;

    InstaPageManager() {
        try {
            Scanner scFile = new Scanner(new File("data.txt"));
            while (scFile.hasNextLine()) {
                Scanner scLine = new Scanner(scFile.nextLine()).useDelimiter("#");

                int id = scLine.nextInt();
                String user = scLine.next();
                String postContent = scLine.next();
                String postDateTime = scLine.next();

                if (scLine.hasNextInt()) {
                    int responseType = scLine.nextInt();
                    response[countResponse] = new Response(id, user, postContent, postDateTime, responseType);
                    countResponse++;
                } else {
                    post[countPost] = new Post(id, user, postContent, postDateTime);
                    countPost++;
                }

            }
        } catch (FileNotFoundException ex) {
            System.out.println("File not found.");
        }

    }

    public String getAllPosts() {
        String str = "";
        for (int i = 0; i < countPost; i++) {
            str += post[i].toString() + "\n";
        }
        return str;
    }

    public String populatePostWithResponses() {
        for (int i = 0; i < countResponse; i++) {
            
            if ((post[i].getId())==(response[i].getPostID())) {
                
                String line = post[i] + "\n" + "\t" + "responses" + " ";
                //new arr[0] = post[i]
                for (int j = 0; j < countResponse; j++) {
                    line += response[j];
                    //arr[1]=response[j]
                }
                return line;
            }
        }
        return null;
    
    }
    
    
    
}


