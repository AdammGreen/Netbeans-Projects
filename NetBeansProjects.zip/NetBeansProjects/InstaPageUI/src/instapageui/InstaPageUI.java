/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package instapageui;

/**
 *
 * @author adamdanielgreen
 */
public class InstaPageUI {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
    InstaPageManager pm = new InstaPageManager();
    
       // System.out.println(pm.getAllPosts()); 
    
        System.out.println(pm.populatePostWithResponses());
    
    
    }
    
 
    
}
