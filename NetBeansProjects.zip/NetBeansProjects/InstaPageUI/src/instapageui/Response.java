/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package instapageui;

/**
 *
 * @author adamdanielgreen
 */
public class Response {

    private int postID;
    private String user;
    private String comment;
    private String responseDateTime;
    private int responseType;

    public static final int RESPONSE_LIKE = 1;
    public static final int RESPONSE_COMMENT = 2;
    public static final int RESPONSE_DISLIKE = 3;
    public static final int RESPONSE_LOVE = 4;

    public Response(int inPostID, String inUser, String inComment, String inResponseDateTime, int inResponseType) {
        this.postID = inPostID;
        this.user = inUser;
        this.comment = inComment;
        this.responseDateTime = inResponseDateTime;
        this.responseType = inResponseType;
    }

    public String getResponseType() {
        String outcome = "";
        switch (responseType) {
            case RESPONSE_LIKE:
                return "liked";
            case RESPONSE_COMMENT:
                return "commented";
            case RESPONSE_DISLIKE:
                return "disliked";
            case RESPONSE_LOVE:
                return "loved";

        }
        return outcome;
    }

    public int getPostID() {
        return postID;
    }

    public String toString() {
        String output = "";
        if (responseType == 2) {
            output = responseDateTime + "\t" + user + " " + responseType + " " + "on this post:" +" " + comment;
        }
        else {
            output = responseDateTime + "\t" + user +" " + responseType + " " + "this post";
        }
    return output;
}
}
