/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package instapageui;

/**
 *
 * @author adamdanielgreen
 */
public class PostWithResponses {
 
    private Post p;
    
   private Response[] responses;

    public PostWithResponses(Post p, Response[] responses) {
        this.p = p;
        this.responses = responses;
    }
   
   
   
   public String toString(){
       String line = p + "\n" + "\t" + "responses" + " ";
       
       
       for(int i = 0;i < responses.length;i++ ){
           line += responses[i];
       }
       return line;
   }
   
   
}
