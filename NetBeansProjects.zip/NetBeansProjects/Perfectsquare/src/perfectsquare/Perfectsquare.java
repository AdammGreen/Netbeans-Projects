/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perfectsquare;

/**
 *
 * @author adamdanielgreen
 */
public class Perfectsquare {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    }
        
        {
            System.out.println("PerfectSquares");
            System.out.println();
            
            int[] numbers = {0,1, 4, 10, 9, 15, 16 };
            
            for ( int number : numbers) {
        }
        
    }
    static boolean isPerfectSquare( int number ) {
        
        boolean result = false;
        int sqrt = (int)Math.sqrt( number );
        result = number == sqrt * sqrt;
        return false; 
    }
    
}
