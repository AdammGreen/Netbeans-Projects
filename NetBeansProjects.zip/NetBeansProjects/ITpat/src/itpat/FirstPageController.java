package itpat;

import static java.awt.SystemColor.window;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class FirstPageController {
//links controller to backend
    SQLBackend sb;
//declares buttons
    @FXML
    private Button btnAdmin;

    @FXML
    private Button btnHelp;

    @FXML
    private Button btnStudent;
/*
    This method is run when the action event parameter is called, this is when the GUI button is clicked. 
    When admin is clicked the student usertype is added as an admin, this means that given the correct login that matches the user type
    the admin section of the code is run. After the button is clicked the login screen is opened
    */
    @FXML
    void adminClicked(ActionEvent event) throws IOException {
        System.out.println("btnAdmin clicked");

        SQLBackend m = new SQLBackend();
        m.setUsertype("Admin");

        Parent login_screen_parent = FXMLLoader.load(getClass().getResource("FXMLLoginScreen.fxml"));
        Scene login_screen_scene = new Scene(login_screen_parent);
        Stage login_screen_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        login_screen_stage.hide();
        login_screen_stage.setScene(login_screen_scene);
        login_screen_stage.show();

    }
/*
    This method is run when the action event parameter is called, this is when the GUI button is clicked. 
    When student is clicked the student usertype is added as a student, this means that given the correct login that matches the user type
    the student section of the code is run. After the button is clicked the login screen is opened
    */
    @FXML
    void studentClicked(ActionEvent event) throws IOException {
        System.out.println("btnStudent clicked");
        SQLBackend m = new SQLBackend();
        m.setUsertype("Student");

        Parent login_screen_parent = FXMLLoader.load(getClass().getResource("FXMLLoginScreen.fxml"));
        Scene login_screen_scene = new Scene(login_screen_parent);
        Stage login_screen_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        login_screen_stage.hide();
        login_screen_stage.setScene(login_screen_scene);
        login_screen_stage.show();

    }
/*
    This method is run when the action event parameter is called, this is when the GUI button is clicked. 
    This method opens a new window which is a seperate root from all the other screens and has its own stage. The scene is set and displayed. 
    There is also a suitable catch method which is displayed if the screen cannot open.
    */
    @FXML
    void helpClicked(ActionEvent event) {
        try {
            System.out.println("Help Clicked");
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("HelpScreen.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            Stage stage = new Stage();
            stage.initStyle(StageStyle.TRANSPARENT);
            stage.setScene(new Scene(root1));
            stage.show();
        } catch (Exception e) {
            System.out.println("Can't open window");
        }

    }

    public void initialize(URL url, ResourceBundle rb) {
        //Links controller to database
        sb = new SQLBackend();
    }

}
