/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package itpat;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import static javafx.application.Application.launch;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * FXML Controller class
 *
 * @author adamdanielgreen
 */
public class PrintTicketScreenController implements Initializable {

    //links to backend
    SQLBackend sb;
//declares fx buttons  
    @FXML
    private Label StudentName;

    @FXML
    private Button btnHelp;
    @FXML
    private Button btnBack;
    @FXML
    private Button btnPrint;
    @FXML
    private Button btnViewPDF;

    @FXML
    private Button btnFinnish;

    @FXML
    private Label quanityLabel;

    @FXML
    private Label priceLabel;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //links to backend 
        sb = new SQLBackend();
//fetches username
        String result = sb.getUsername();
        System.out.println("Returned msg: " + result);
//displays a thank you message with fetched username
        StudentName.setText("Thank you for purchasing " + result);
//displays quanitiy of tickets bought in the quanitity label and pricelabel and works out total cost in the pricelable. 
//The database is acces through the backend and is called up
        int countResult = sb.getCount();
        System.out.println("Returned msg: " + countResult);
        String str = countResult + "";
        quanityLabel.setText(str);

        String name = sb.getProductionName();
        System.out.println("Returned msg: " + name);

        priceLabel.setText("R" + Integer.parseInt(sb.ticketPriceCheck(name)) * countResult);

    }

    /*
    This method is run when the action event parameter is called, this is when the GUI button is clicked. 
    This method opens a new window which is a seperate root from all the other screens and has its own stage. 
    The scene is set and displayed. There is also a suitable catch method which is displayed if the screen cannot open.
     */
    @FXML
    private void helpClicked(ActionEvent event) {
        try {
            System.out.println("Help Clicked");
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("HelpScreen.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            Stage stage = new Stage();
            stage.initStyle(StageStyle.TRANSPARENT);
            stage.setScene(new Scene(root1));
            stage.show();
        } catch (Exception e) {
            System.out.println("Can't open window");
        }
    }

    /*
    This method is run when the action event parameter is called, this is when the GUI button is clicked. 
    This method loads the previous GUI which is ChooseSeatScreen and displays it once the user has clicked the next button. 
    The previous screen is closed with the .hide() function and opens the next screen with the .show() function and a new scene is set.
    
     */
    @FXML
    private void btnBackClicked(ActionEvent event) throws IOException {
        System.out.println("btnBack clicked");

        Parent btnback_screen_parent = FXMLLoader.load(getClass().getResource("ChooseSeatScreen.fxml"));
        Scene btnback_screen_scene = new Scene(btnback_screen_parent);
        Stage btnback_screen_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        btnback_screen_stage.hide();
        btnback_screen_stage.setScene(btnback_screen_scene);
        btnback_screen_stage.show();

    }

    /*
    This method is run when the action event parameter is called, this is when the GUI button is clicked. 
    this method prints the final Gui screen with the ticket on it. A new Printjob is created and format is selected. 
    There is a check to see that there actually is something to print and there is a catch incase there isnt. 
    The page is then selected to be painted(printed) and is printed when the button is clicked.
     */

    @FXML
    public void btnPrintClicked(ActionEvent event) {

        PrinterJob pj = PrinterJob.getPrinterJob();
        pj.setJobName(" Print Component ");

        pj.setPrintable(new Printable() {
            public int print(Graphics pg, PageFormat pf, int pageNum) {
                if (pageNum > 0) {
                    return Printable.NO_SUCH_PAGE;
                }

                Graphics2D g2 = (Graphics2D) pg;
                g2.translate(pf.getImageableX(), pf.getImageableY());
                // PrintTicketScreenController.paint(g2);
                return Printable.PAGE_EXISTS;
            }
        });

        if (pj.printDialog() == false) {
            return;
        }

        try {
            pj.print();
        } catch (PrinterException ex) {
            System.out.println("Could not be printed");
        }

    }

    /*
    This method is run when the action event parameter is called, this is when the GUI button is clicked. 
    The following method ends the program and closes the GUI stage and all included scenes.
     */

    @FXML
    void btnFinnishClicked(ActionEvent event) {

        final Node source = (Node) event.getSource();
        final Stage stage = (Stage) source.getScene().getWindow();
        stage.close();
    }

}
