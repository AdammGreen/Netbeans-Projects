package itpat;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class ChooseProductionScreenController implements Initializable {

    //constructors for the fx buttons
    @FXML
    private Button btnNext;

    @FXML
    private ImageView SJC;

    @FXML
    private ChoiceBox<String> productionDropdown;

    @FXML
    private ChoiceBox<String> dateDropdown;

    @FXML
    private Button btnHelp;

    @FXML
    private Label helloMessage;

    /*
    This method is run when the action event parameter is called, this is when the GUI button is clicked. 
    This method loads the next GUI which is ChooseSeatScreen and displays it once the user has clicked the next button. The previous screen is closed with 
    the .hide() function and opens the next screen with the .show() function and a new scene is set.
    
     */
    @FXML
    void nextClicked(ActionEvent event) throws IOException {
        System.out.println("Next Clicked");
        Parent seat_screen_parent = FXMLLoader.load(getClass().getResource("ChooseSeatScreen.fxml"));
        Scene seat_screen_scene = new Scene(seat_screen_parent);
        Stage seat_screen_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

        seat_screen_stage.hide();
        seat_screen_stage.setScene(seat_screen_scene);
        seat_screen_stage.show();
    }

    /*
    This method is run when the action event parameter is called, this is when the GUI button is clicked. 
    This method opens a new window which is a seperate root from all the other screens and has its own stage. The scene is set and displayed. There is also a 
    suitable catch method which is displayed if the screen cannot open.
     */
    @FXML
    void helpClicked(ActionEvent event) {
        try {
            System.out.println("Help Clicked");
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("HelpScreen.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            Stage stage = new Stage();
            stage.initStyle(StageStyle.TRANSPARENT);
            stage.setScene(new Scene(root1));
            stage.show();
        } catch (Exception e) {
            System.out.println("Can't open window");
        }
    }

    /*
    This method is run when the action event parameter is called, this is when the GUI button is clicked. 
    This method method takes the production that the user choice from a choicebox and saves it in the backend.
    A date is then displayed in another choicebox and this date is displayed based on what production was chosen and saved in backend.
    The date is retrieved in the backend with a method that uses and sql statemnt to fetch the date from the database
     */
    @FXML
    private void productionChosen(ActionEvent event) {
        SQLBackend sb = new SQLBackend();
        String name;

        System.out.println(productionDropdown.getValue());

        if (productionDropdown.getValue().equals("macbeth")) {

            sb.setProductionName("Macbeth");
            System.out.println("Prouction Name Set to Macbeth");

        } else if (productionDropdown.getValue().equals("feda")) {
            sb.setProductionName("Feda");
            System.out.println("Prouction Name Set to Macbeth");
        }

        if (productionDropdown.getValue().equals("macbeth")) {     //this is so that each porduction has different dates to choose from
            ObservableList<String> dateList = FXCollections.observableArrayList();
            dateList.add("2019/04/19");
            dateDropdown.setItems(dateList);
            // sb.updateProductionScreen("macbeth","1"); //need to actually be able to call the userID. That 1 is just a test variable

        } else if (productionDropdown.getValue().equals("feda")) {
            ObservableList<String> dateList = FXCollections.observableArrayList();
            dateList.add("2019/04/20");
            dateDropdown.setItems(dateList);
            // sb.updateProductionScreen("feda","2");//need to actually be able to call the userID. That 1 is just a test variable
        }

    }

    /*
    This method intializes the choicebox and what production will be displayed
    
     */
    @Override
    public void initialize(URL location, ResourceBundle resources) {

        /*
        this code links the backend to the ui code. The Observablelist is also instalized to show the productions that are airing and alows the
        user to select one.
         */
        SQLBackend sb = new SQLBackend();

        ObservableList<String> productionList = FXCollections.observableArrayList();
        productionList.add("macbeth");
        productionList.add("feda");
        productionDropdown.setItems(productionList);

        /*
        This method retrieves the username to be displayed and intialized on the screen with a getter method that 
        fetches the username that was eneter in the login screen
         */
        String result = sb.getUsername();
        System.out.println("Returned msg: " + result);

        helloMessage.setText("Hello " + result);

    }

}
