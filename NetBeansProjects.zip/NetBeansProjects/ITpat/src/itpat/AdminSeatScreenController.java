/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package itpat;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.beans.value.ObservableValue;

/**
 * FXML Controller class
 *
 * @author adamdanielgreen
 */
public class AdminSeatScreenController implements Initializable {
//links backend and intializes count variable
    SQLBackend sb;
    int count = 0;
//constructors for the fx buttons
    @FXML
    private Button btnFinish;
    @FXML
    private Button btnHelp;
    @FXML
    private Button btnB1;
    @FXML
    private Button btnA1;
    @FXML
    private Button btnD1;
    @FXML
    private Button btnC1;
    @FXML
    private Button btnD5;
    @FXML
    private Button btnC5;
    @FXML
    private Button btnB5;
    @FXML
    private Button btnA5;
    @FXML
    private Button btnA4;
    @FXML
    private Button btnD3;
    @FXML
    private Button btnC3;
    @FXML
    private Button btnA3;
    @FXML
    private Button btnD2;
    @FXML
    private Button btnB2;
    @FXML
    private Button btnA2;
    @FXML
    private Button btnC2;
    @FXML
    private Button btnB3;
    @FXML
    private Button btnD4;
    @FXML
    private Button btnC4;
    @FXML
    private Button btnB4;
    @FXML
    private TextField MakeAvailable;
    @FXML
    private TextField MakeUnavailable;
    @FXML
    private TextField refundAmount;
    @FXML
    private TextField bookersName;
    @FXML
    private ChoiceBox<String> production;

    /*
    The following method ends the program and closes the GUI stage and all included scenes.
     */
    @FXML
    private void btnFinishClicked(ActionEvent event) {
        final Node source = (Node) event.getSource();
        final Stage stage = (Stage) source.getScene().getWindow();
        stage.close();
    }

    /*
   This method is run when the action event parameter is called, this is when the GUI button is clicked. 
    This method opens a new window which is a seperate root from all the other screens and has its own stage. The scene is set and displayed. 
    There is also a suitable catch method which is displayed if the screen cannot open.
     */
    @FXML
    private void btnHelpClicked(ActionEvent event) {
        System.out.println("Help Clicked");
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("HelpScreen.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            Stage stage = new Stage();
            stage.initStyle(StageStyle.TRANSPARENT);
            stage.setTitle("Help S");
            stage.setScene(new Scene(root1));
            stage.show();
        } catch (Exception e) {
            System.out.println("Can't load new window");
        }
    }

    /*
    This method is run when the action event parameter is called, this is when the GUI button is clicked. 
    The following button methods are used to check if a seat is available based on its buttons colour.
    If the the seat is clicked then a count method is run to count the amount of seats selected
    There are 2 methods that are used to paramater pass the buttons row and seat letter to the backened where various methods are using them
    There is also a backend method that updates the seats availability status
     */
    @FXML
    void btnA1Clicked(ActionEvent event) {

        if (sb.isAvailable(btnA1.getStyle()) == true) {
            btnA1.setStyle("-fx-background-color: #434b4d");
            count = count + 1;
            sb.setSeatLetter("A");
            sb.setSeatNumber(1);
            sb.updateSeating();
            //sb.IsSeatAvailable("A1");
        }
    }

    @FXML
    void btnA2Clicked(ActionEvent event) {

        if (sb.isAvailable(btnA2.getStyle()) == true) {
            btnA2.setStyle("-fx-background-color: #434b4d");
            count = count + 1;
            sb.setSeatLetter("A");
            sb.setSeatNumber(2);
            sb.updateSeating();
            // sb.IsSeatAvailable("A2");
        }

    }

    @FXML
    void btnA3Clicked(ActionEvent event) {

        if (sb.isAvailable(btnA3.getStyle()) == true) {
            btnA3.setStyle("-fx-background-color: #434b4d");
            count = count + 1;
            sb.setSeatLetter("A");
            sb.setSeatNumber(3);
            sb.updateSeating();
            //   sb.IsSeatAvailable("A3");
        }

    }

    @FXML
    void btnA4Clicked(ActionEvent event) {

        if (sb.isAvailable(btnA4.getStyle()) == true) {
            btnA4.setStyle("-fx-background-color: #434b4d");
            count = count + 1;
            sb.setSeatLetter("A");
            sb.setSeatNumber(4);
            sb.updateSeating();
            //  sb.IsSeatAvailable("A4");
        }

    }

    @FXML
    void btnA5Clicked(ActionEvent event) {

        if (sb.isAvailable(btnA5.getStyle()) == true) {
            btnA5.setStyle("-fx-background-color: #434b4d");
            count = count + 1;
            sb.setSeatLetter("A");
            sb.setSeatNumber(5);
            sb.updateSeating();
            // sb.IsSeatAvailable("A5");
        }
    }

    @FXML
    void btnB1Clicked(ActionEvent event) {

        if (sb.isAvailable(btnB1.getStyle()) == true) {
            btnB1.setStyle("-fx-background-color: #434b4d");
            count = count + 1;
            sb.setSeatLetter("B");
            sb.setSeatNumber(1);
            sb.updateSeating();
            // sb.IsSeatAvailable("B1");
        }
    }

    @FXML
    void btnB2Clicked(ActionEvent event) {
        if (sb.isAvailable(btnB2.getStyle()) == true) {
            btnB2.setStyle("-fx-background-color: #434b4d");
            count = count + 1;
            sb.setSeatLetter("B");
            sb.setSeatNumber(2);
            sb.updateSeating();
            //     sb.IsSeatAvailable("B2");
        }
    }

    @FXML
    void btnB3Clicked(ActionEvent event) {
        if (sb.isAvailable(btnB3.getStyle()) == true) {
            btnB3.setStyle("-fx-background-color: #434b4d");
            count = count + 1;
            sb.setSeatLetter("B");
            sb.setSeatNumber(3);
            sb.updateSeating();
            //   sb.IsSeatAvailable("B3");
        }
    }

    @FXML
    void btnB4Clicked(ActionEvent event) {
        if (sb.isAvailable(btnB4.getStyle()) == true) {
            btnB4.setStyle("-fx-background-color: #434b4d");
            count = count + 1;
            sb.setSeatLetter("B");
            sb.setSeatNumber(4);
            //   sb.updateSeating();
        }
    }

    @FXML
    void btnB5Clicked(ActionEvent event) {
        if (sb.isAvailable(btnB5.getStyle()) == true) {
            btnB5.setStyle("-fx-background-color: #434b4d");
            count = count + 1;
            sb.setSeatLetter("B");
            sb.setSeatNumber(5);
            sb.updateSeating();
            //  sb.IsSeatAvailable("B5");
        }
    }

    @FXML
    void btnC1Clicked(ActionEvent event) throws SQLException {
        if (sb.isAvailable(btnC1.getStyle()) == true) {
            btnC1.setStyle("-fx-background-color: #434b4d");
            count = count + 1;
            sb.setSeatLetter("C");
            sb.setSeatNumber(1);
            sb.updateSeating();
            //  sb.IsSeatAvailable("C1");
        }
        // if(sb.IsSeatAvailable() == false){
        //btnC1.setStyle("fx-background-color: #434b4d");
        //}
    }

    @FXML
    void btnC2Clicked(ActionEvent event) {
        if (sb.isAvailable(btnC2.getStyle()) == true) {
            btnC2.setStyle("-fx-background-color: #434b4d");
            count = count + 1;
            sb.setSeatLetter("C");
            sb.setSeatNumber(2);
            sb.updateSeating();
            //  sb.IsSeatAvailable("C2");
        }
    }

    @FXML
    void btnC3Clicked(ActionEvent event) {
        if (sb.isAvailable(btnC3.getStyle()) == true) {
            btnC3.setStyle("-fx-background-color: #434b4d");
            count = count + 1;
            sb.setSeatLetter("C");
            sb.setSeatNumber(3);
            sb.updateSeating();
            //  sb.IsSeatAvailable("C3");
        }
    }

    @FXML
    void btnC4Clicked(ActionEvent event) {
        if (sb.isAvailable(btnC4.getStyle()) == true) {
            btnC4.setStyle("-fx-background-color: #434b4d");
            count = count + 1;
            sb.setSeatLetter("C");
            sb.setSeatNumber(4);
            sb.updateSeating();
            //  sb.IsSeatAvailable("C4");
        }
    }

    @FXML
    void btnC5Clicked(ActionEvent event) {
        if (sb.isAvailable(btnC5.getStyle()) == true) {
            btnC5.setStyle("-fx-background-color: #434b4d");
            sb.setSeatLetter("C");
            sb.setSeatNumber(5);
            sb.updateSeating();
            //  sb.IsSeatAvailable("C5");
        }
    }

    @FXML
    void btnD1Clicked(ActionEvent event) {
        if (sb.isAvailable(btnD1.getStyle()) == true) {
            btnD1.setStyle("-fx-background-color: #434b4d");
            count = count + 1;
            sb.setSeatLetter("D");
            sb.setSeatNumber(1);
            sb.updateSeating();
            // sb.IsSeatAvailable("D1");
        }
    }

    @FXML
    void btnD2Clicked(ActionEvent event) {
        if (sb.isAvailable(btnD2.getStyle()) == true) {
            btnD2.setStyle("-fx-background-color: #434b4d");
            count = count + 1;
            sb.setSeatLetter("D");
            sb.setSeatNumber(2);
            sb.updateSeating();
            // sb.IsSeatAvailable("D2");
        }

    }

    @FXML
    void btnD3Clicked(ActionEvent event) {
        if (sb.isAvailable(btnD3.getStyle()) == true) {
            btnD3.setStyle("-fx-background-color: #434b4d");
            count = count + 1;
            sb.setSeatLetter("D");
            sb.setSeatNumber(3);
            sb.updateSeating();
            // sb.IsSeatAvailable("D3");
        }
    }

    @FXML
    void btnD4Clicked(ActionEvent event) {
        if (sb.isAvailable(btnD4.getStyle()) == true) {
            btnD4.setStyle("-fx-background-color: #434b4d");
            count = count + 1;
            sb.setSeatLetter("D");
            sb.setSeatNumber(4);
            sb.updateSeating();
            // sb.IsSeatAvailable("D4");
        }
    }

    @FXML
    void btnD5Clicked(ActionEvent event) {
        if (sb.isAvailable(btnA3.getStyle()) == true) {
            btnD5.setStyle("-fx-background-color: #434b4d");
            count = count + 1;
            sb.setSeatLetter("D");
            sb.setSeatNumber(5);
            sb.updateSeating();
            //  sb.IsSeatAvailable("D5");
        }
    }

    /*
    This method is run when the action event parameter is called, this is when the GUI button is clicked. 
    The following method is used to retrieve the seats availabilty status from the backend and then the database. 
    The method then intialize the colour of the seat based on its availability status. The method also allows the user to pass the seats
    row letter and number to the backend and into the the sb.makeAvailable method which will make it available if unavailable
     */
    @FXML
    private void SeatMadeAvailable(ActionEvent event) {
        System.out.println("I got called");
        if (sb.makeAvailable(production.getValue(), MakeAvailable.getText())) {
            switch (MakeAvailable.getText()) {
                case "A1":
                    btnA1.setStyle("-fx-background-color: #01579b");
            }
            if (sb.makeAvailable(production.getValue(), MakeAvailable.getText())) {
                switch (MakeAvailable.getText()) {
                    case "A2":
                        btnA2.setStyle("-fx-background-color: #01579b");
                }

                if (sb.makeAvailable(production.getValue(), MakeAvailable.getText())) {
                    switch (MakeAvailable.getText()) {
                        case "A3":
                            btnA3.setStyle("-fx-background-color: #01579b");
                    }
                }
                if (sb.makeAvailable(production.getValue(), MakeAvailable.getText())) {
                    switch (MakeAvailable.getText()) {
                        case "A4":
                            btnA4.setStyle("-fx-background-color: #01579b");
                    }
                }
                if (sb.makeAvailable(production.getValue(), MakeAvailable.getText())) {
                    switch (MakeAvailable.getText()) {
                        case "B1":
                            btnB1.setStyle("-fx-background-color: #01579b");
                    }
                }
                if (sb.makeAvailable(production.getValue(), MakeAvailable.getText())) {
                    switch (MakeAvailable.getText()) {
                        case "B2":
                            btnB2.setStyle("-fx-background-color: #01579b");
                    }
                }if (sb.makeAvailable(production.getValue(), MakeAvailable.getText())) {
                    switch (MakeAvailable.getText()) {
                        case "B3":
                            btnB3.setStyle("-fx-background-color: #01579b");
                    }
                }if (sb.makeAvailable(production.getValue(), MakeAvailable.getText())) {
                    switch (MakeAvailable.getText()) {
                        case "B4":
                            btnB4.setStyle("-fx-background-color: #01579b");
                    }
                }if (sb.makeAvailable(production.getValue(), MakeAvailable.getText())) {
                    switch (MakeAvailable.getText()) {
                        case "C1":
                            btnC1.setStyle("-fx-background-color: #01579b");
                    }
                }if (sb.makeAvailable(production.getValue(), MakeAvailable.getText())) {
                    switch (MakeAvailable.getText()) {
                        case "C2":
                            btnC2.setStyle("-fx-background-color: #01579b");
                    }
                }if (sb.makeAvailable(production.getValue(), MakeAvailable.getText())) {
                    switch (MakeAvailable.getText()) {
                        case "C3":
                            btnC3.setStyle("-fx-background-color: #01579b");
                    }
                }if (sb.makeAvailable(production.getValue(), MakeAvailable.getText())) {
                    switch (MakeAvailable.getText()) {
                        case "C4":
                            btnC4.setStyle("-fx-background-color: #01579b");
                    }
                }if (sb.makeAvailable(production.getValue(), MakeAvailable.getText())) {
                    switch (MakeAvailable.getText()) {
                        case "D1":
                            btnD1.setStyle("-fx-background-color: #01579b");
                    }
                }if (sb.makeAvailable(production.getValue(), MakeAvailable.getText())) {
                    switch (MakeAvailable.getText()) {
                        case "D2":
                            btnD2.setStyle("-fx-background-color: #01579b");
                    }
                }if (sb.makeAvailable(production.getValue(), MakeAvailable.getText())) {
                    switch (MakeAvailable.getText()) {
                        case "D3":
                            btnA4.setStyle("-fx-background-color: #01579b");
                    }
                }if (sb.makeAvailable(production.getValue(), MakeAvailable.getText())) {
                    switch (MakeAvailable.getText()) {
                        case "D4":
                            btnA4.setStyle("-fx-background-color: #01579b");
                    }
                }
            }
        }

    }

     /*
    This method is run when the action event parameter is called, this is when the GUI button is clicked. 
    The following method is used to retrieve the seats availabilty status from the backend and then the database. 
    The method then intialize the colour of the seat based on its availability status. The method also allows the user to pass the seats
    row letter and number and userID (person who is booking the seat) to the backend and into the the sb.makeUnavailable method which will 
    make it unavailable  if available
     */
    
    
    @FXML
    private void SeatMadeUnavailable(ActionEvent event
    ) {
        if (sb.makeUnAvailable(bookersName.getText(), production.getValue(), MakeUnavailable.getText())) {
            switch (MakeAvailable.getText()) {
                case "A1":
                    btnA1.setStyle("-fx-background-color: #434b4d");
            }
        }
        if (sb.makeUnAvailable(bookersName.getText(), production.getValue(), MakeUnavailable.getText())) {
            switch (MakeAvailable.getText()) {
                case "A2":
                    btnA2.setStyle("-fx-background-color: #434b4d");
            }
        }
        if (sb.makeUnAvailable(bookersName.getText(), production.getValue(), MakeUnavailable.getText())) {
            switch (MakeAvailable.getText()) {
                case "A3":
                    btnA3.setStyle("-fx-background-color: #434b4d");
            }
        }
        if (sb.makeUnAvailable(bookersName.getText(), production.getValue(), MakeUnavailable.getText())) {
            switch (MakeAvailable.getText()) {
                case "B1":
                    btnB1.setStyle("-fx-background-color: #434b4d");
            }
        }
        if (sb.makeUnAvailable(bookersName.getText(), production.getValue(), MakeUnavailable.getText())) {
            switch (MakeAvailable.getText()) {
                case "B2":
                    btnB2.setStyle("-fx-background-color: #434b4d");
            }
        }
        if (sb.makeUnAvailable(bookersName.getText(), production.getValue(), MakeUnavailable.getText())) {
            switch (MakeAvailable.getText()) {
                case "B3":
                    btnB3.setStyle("-fx-background-color: #434b4d");
            }
        }
        if (sb.makeUnAvailable(bookersName.getText(), production.getValue(), MakeUnavailable.getText())) {
            switch (MakeAvailable.getText()) {
                case "B4":
                    btnB4.setStyle("-fx-background-color: #434b4d");
            }
        }
        if (sb.makeUnAvailable(bookersName.getText(), production.getValue(), MakeUnavailable.getText())) {
            switch (MakeAvailable.getText()) {
                case "C1":
                    btnC1.setStyle("-fx-background-color: #434b4d");
            }
        }
        if (sb.makeUnAvailable(bookersName.getText(), production.getValue(), MakeUnavailable.getText())) {
            switch (MakeAvailable.getText()) {
                case "C2":
                    btnC2.setStyle("-fx-background-color: #434b4d");
            }
        }
        if (sb.makeUnAvailable(bookersName.getText(), production.getValue(), MakeUnavailable.getText())) {
            switch (MakeAvailable.getText()) {
                case "C3":
                    btnC3.setStyle("-fx-background-color: #434b4d");
            }
        }
        if (sb.makeUnAvailable(bookersName.getText(), production.getValue(), MakeUnavailable.getText())) {
            switch (MakeAvailable.getText()) {
                case "C4":
                    btnC4.setStyle("-fx-background-color: #434b4d");
            }
        }
        if (sb.makeUnAvailable(bookersName.getText(), production.getValue(), MakeUnavailable.getText())) {
            switch (MakeAvailable.getText()) {
                case "D1":
                    btnD1.setStyle("-fx-background-color: #434b4d");
            }
        }
        if (sb.makeUnAvailable(bookersName.getText(), production.getValue(), MakeUnavailable.getText())) {
            switch (MakeAvailable.getText()) {
                case "D2":
                    btnD2.setStyle("-fx-background-color: #434b4d");
            }
        }
        if (sb.makeUnAvailable(bookersName.getText(), production.getValue(), MakeUnavailable.getText())) {
            switch (MakeAvailable.getText()) {
                case "D3":
                    btnD3.setStyle("-fx-background-color: #434b4d");
            }
        }
        if (sb.makeUnAvailable(bookersName.getText(), production.getValue(), MakeUnavailable.getText())) {
            switch (MakeAvailable.getText()) {
                case "D4":
                    btnD4.setStyle("-fx-background-color: #434b4d");
            }
        }
        
        
    }

    @FXML
    private void refundAmount(ActionEvent event
    ) {  //cant open database and lost image of collumn names so i cant code this method
        //merely have to call an update method that i will make in backend and update user accountbalance with amount entered into refund amount
        //sb.ticketPriceCheck(production.getValue());

    }

    @FXML
    private void bookersName(ActionEvent event
    ) {  //hover method
        //just enter a value but doesn't do anything 
    }

   
    /*
    Method makes the colour of the seat button to match the availibility of the seat in the backend. A parameter is passed called string name
    and this is used to check the name of the production against the availability of its seats. this availabilitiy is checked in the backend and
    through a databse
    */
    
    @FXML
    private void productionChosen(String name) {
        //connects to backend
        SQLBackend sb = new SQLBackend();

        System.out.println(name);

        if (production.getValue().equals("macbeth")) {

            sb.setProductionName("Macbeth");
            System.out.println("Prouction Name Set to Macbeth");

        } else if (production.getValue().equals("feda")) {
            sb.setProductionName("Feda");
            System.out.println("Prouction Name Set to Macbeth");
        }
        //A seats
        if (sb.IsSeatAvailable(name, "A1")) {
            btnA1.setStyle("-fx-background-color: #01579b");
        } else {
            btnA1.setStyle("-fx-background-color: #434b4d");
        }
        if (sb.IsSeatAvailable(production.getValue(), "A3")) {
            btnA3.setStyle("-fx-background-color: #01579b");
        } else {
            btnA3.setStyle("-fx-background-color: #434b4d");
        }
        if (sb.IsSeatAvailable(production.getValue(), "A4")) {
            btnA4.setStyle("-fx-background-color: #01579b");
        } else {
            btnA4.setStyle("-fx-background-color: #434b4d");
        }
        if (sb.IsSeatAvailable(production.getValue(), "A5")) {
            btnA5.setStyle("-fx-background-color: #01579b");
        } else {
            btnA5.setStyle("-fx-background-color: #434b4d");

            //B Seats
        }
        if (sb.IsSeatAvailable(production.getValue(), "B1")) {
            btnB1.setStyle("-fx-background-color: #01579b");
        } else {
            btnB1.setStyle("-fx-background-color: #434b4d");
        }
        if (sb.IsSeatAvailable(production.getValue(), "B2")) {
            btnB2.setStyle("-fx-background-color: #01579b");
        } else {
            btnB2.setStyle("-fx-background-color: #434b4d");
        }
        if (sb.IsSeatAvailable(production.getValue(), "B3")) {
            btnB3.setStyle("-fx-background-color: #01579b");
        } else {
            btnB3.setStyle("-fx-background-color: #434b4d");
        }
        if (sb.IsSeatAvailable(production.getValue(), "B4")) {
            btnB4.setStyle("-fx-background-color: #01579b");
        } else {
            btnB4.setStyle("-fx-background-color: #434b4d");
        }
        if (sb.IsSeatAvailable(production.getValue(), "B5")) {
            btnB5.setStyle("-fx-background-color: #01579b");
        } else {
            btnB5.setStyle("-fx-background-color: #434b4d");
        }

        //c seats
        if (sb.IsSeatAvailable(production.getValue(), "C1")) {
            btnC1.setStyle("-fx-background-color: #01579b");
        } else {
            btnC1.setStyle("-fx-background-color: #434b4d");
        }
        if (sb.IsSeatAvailable(production.getValue(), "C2")) {
            btnC2.setStyle("-fx-background-color: #01579b");
        } else {
            btnC2.setStyle("-fx-background-color: #434b4d");
        }
        if (sb.IsSeatAvailable(production.getValue(), "C3")) {
            btnC3.setStyle("-fx-background-color: #01579b");
        } else {
            btnC3.setStyle("-fx-background-color: #434b4d");
        }
        if (sb.IsSeatAvailable(production.getValue(), "C4")) {
            btnC4.setStyle("-fx-background-color: #01579b");
        } else {
            btnC4.setStyle("-fx-background-color: #434b4d");
        }
        if (sb.IsSeatAvailable(production.getValue(), "C5")) {
            btnC5.setStyle("-fx-background-color: #01579b");
        } else {
            btnC5.setStyle("-fx-background-color: #434b4d");
        }

        //d seats
        if (sb.IsSeatAvailable(production.getValue(), "D1")) {
            btnD1.setStyle("-fx-background-color: #01579b");
        } else {
            btnD1.setStyle("-fx-background-color: #434b4d");
        }
        if (sb.IsSeatAvailable(production.getValue(), "D2")) {
            btnD2.setStyle("-fx-background-color: #01579b");
        } else {
            btnD2.setStyle("-fx-background-color: #434b4d");
        }
        if (sb.IsSeatAvailable(production.getValue(), "D3")) {
            btnD3.setStyle("-fx-background-color: #01579b");
        } else {
            btnD3.setStyle("-fx-background-color: #434b4d");
        }
        if (sb.IsSeatAvailable(production.getValue(), "D4")) {
            btnD4.setStyle("-fx-background-color: #01579b");
        } else {
            btnD4.setStyle("-fx-background-color: #434b4d");
        }
        if (sb.IsSeatAvailable(production.getValue(), "D5")) {
            btnD5.setStyle("-fx-background-color: #01579b");
        } else {
            btnD5.setStyle("-fx-background-color: #434b4d");
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources
    ) {
/*
        The methods within the intialize make the choicebox show what productions are airing. It also implements a tooltip method which
        allows the user to see a tooltip when hovering the mouse over a seat button and the tooltip displays the userID of who booked the seat
        There is a running buttonlistener which allows for the screen to change when an update in the seat buttons availibitiy is seen to have changed
        */
        sb = new SQLBackend();
//links method to backend
        ObservableList<String> productionList = FXCollections.observableArrayList();
        productionList.add("macbeth");
        productionList.add("feda");
        production.setItems(productionList);
        production.getSelectionModel().selectedItemProperty().addListener((ObservableValue<? extends String> observable, String oldValue, String newValue) -> productionChosen(newValue));

        //A1-A5 tooltips
        final Tooltip tooltipA1 = new Tooltip();
        String userID1 = sb.tooltipName(production.getValue());
        tooltipA1.setText(userID1);
        btnA1.setTooltip(tooltipA1);
        btnA1.setStyle("-fx-background-color: #01579b");

        final Tooltip tooltipA2 = new Tooltip();
        String userID2 = sb.tooltipName(production.getValue());
        tooltipA2.setText(userID2);
        btnA2.setTooltip(tooltipA2);

        final Tooltip tooltipA3 = new Tooltip();
        String userID3 = sb.tooltipName(production.getValue());
        tooltipA3.setText(userID3);
        btnA3.setTooltip(tooltipA3);

        final Tooltip tooltipA4 = new Tooltip();
        String userID4 = sb.tooltipName(production.getValue());
        tooltipA4.setText(userID4);
        btnA4.setTooltip(tooltipA4);

        final Tooltip tooltipA5 = new Tooltip();
        String userID5 = sb.tooltipName(production.getValue());
        tooltipA5.setText(userID5);
        btnA5.setTooltip(tooltipA5);

        //B1-B5 Tooltips
        final Tooltip tooltipB1 = new Tooltip();
        String userID6 = sb.tooltipName(production.getValue());
        tooltipB1.setText(userID6);
        btnB1.setTooltip(tooltipB1);

        final Tooltip tooltipB2 = new Tooltip();
        String userID7 = sb.tooltipName(production.getValue());
        tooltipB2.setText(userID7);
        btnB2.setTooltip(tooltipB2);

        final Tooltip tooltipB3 = new Tooltip();
        String userID8 = sb.tooltipName(production.getValue());
        tooltipB3.setText(userID8);
        btnB3.setTooltip(tooltipB3);

        final Tooltip tooltipB4 = new Tooltip();
        String userID9 = sb.tooltipName(production.getValue());
        tooltipB4.setText(userID9);
        btnB4.setTooltip(tooltipB4);

        final Tooltip tooltipB5 = new Tooltip();
        String userID10 = sb.tooltipName(production.getValue());
        tooltipB5.setText(userID10);
        btnB5.setTooltip(tooltipB5);

        //C1-C5 tooltips
        final Tooltip tooltipC1 = new Tooltip();
        String userID11 = sb.tooltipName(production.getValue());
        tooltipC1.setText(userID11);
        btnC1.setTooltip(tooltipC1);

        final Tooltip tooltipC2 = new Tooltip();
        String userID12 = sb.tooltipName(production.getValue());
        tooltipC2.setText(userID12);
        btnC2.setTooltip(tooltipC2);

        final Tooltip tooltipC3 = new Tooltip();
        String userID13 = sb.tooltipName(production.getValue());
        tooltipC3.setText(userID13);
        btnC3.setTooltip(tooltipC3);

        final Tooltip tooltipC4 = new Tooltip();
        String userID14 = sb.tooltipName(production.getValue());
        tooltipC4.setText(userID14);
        btnC4.setTooltip(tooltipC4);

        final Tooltip tooltipC5 = new Tooltip();
        String userID15 = sb.tooltipName(production.getValue());
        tooltipC5.setText(userID15);
        btnC5.setTooltip(tooltipC5);

        //D1-D5 Tooltips
        final Tooltip tooltipD1 = new Tooltip();
        String userID16 = sb.tooltipName(production.getValue());
        tooltipD1.setText(userID16);
        btnD1.setTooltip(tooltipD1);

        final Tooltip tooltipD2 = new Tooltip();
        String userID17 = sb.tooltipName(production.getValue());
        tooltipD2.setText(userID17);
        btnD2.setTooltip(tooltipD2);

        final Tooltip tooltipD3 = new Tooltip();
        String userID18 = sb.tooltipName(production.getValue());
        tooltipD3.setText(userID18);
        btnD3.setTooltip(tooltipD3);

        final Tooltip tooltipD4 = new Tooltip();
        String userID19 = sb.tooltipName(production.getValue());
        tooltipD4.setText(userID19);
        btnD4.setTooltip(tooltipD4);

        final Tooltip tooltipD5 = new Tooltip();
        String userID20 = sb.tooltipName(production.getValue());
        tooltipD5.setText(userID20);
        btnD5.setTooltip(tooltipD5);
    }
}
