/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package itpat;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author adamdanielgreen
 */
public class SQLBackend {
//intializes a connection object that will be between backend and database

    private Connection conn;

    //declares all the objects needed
    private static String username;
    private static int count;
    private static String productionName;
    private static String usertype;
    private static String seatLetter;
    private static int seatNumber;

    //creates a connection between the backend and the database and has a catch statemnt incase it cant be found
    public SQLBackend() {
        String databaseURL = "jdbc:ucanaccess://UserSpecsTable.accdb";
        try {
            conn = DriverManager.getConnection(databaseURL);
        } catch (SQLException ex) {
            System.out.println("Cannot connect to database:" + ex);
        }

    }

    /*
   This method creates a result set which is used to output the details selected from database and to excute query statements within the database
     */
    public ResultSet getResults(String query) {
        ResultSet rs = null;
        try {
            Statement stmt = conn.createStatement();
            rs = stmt.executeQuery(query);
        } catch (SQLException ex) {
            System.out.println("Could not execute query:" + ex);
        }
        return rs;
    }

    /*
    This method is used to check wether the user login entered by the student or admin in the login page is correct. 
    The method fetches the the username and password(parameters) from the login page and uses a sql query to compare the password to the username entered. 
    If the username entered exists and the password matches, the boolean value of the method is set to true which allows the user to preceed 
    to the next page. There is a catch statement if the database doesn't respond to the query
     */
    public boolean isValidCredentials(String username, String password) {
        boolean let_in = false;

        ResultSet rs = getResults("SELECT * FROM UserSpecs WHERE UsernameLogin ='" + username + "'");

        try {

            if (rs.next()) {
                if (rs.getString("passwordLogin").equals(password)) {
                    return true;

                }

            }
        } catch (SQLException ex) {
            System.out.println("Error with result set:" + ex);
        }
//System.out.println("SELECT * FROM UserSpecs WHERE UsernameLogin ='" + username + "'");
        return let_in;

    }

    /*
    This method allows for sql update queries to be run in the backend and a connection is made so that thesequeires link to the
    database so that the correct resultset is displayed.
     */
    public void Update(String query) {
        try {
            Statement stmt = conn.createStatement();
            stmt.executeUpdate(query);
        } catch (SQLException ex) {
            System.out.println("Could not update database: " + ex);
        }
    }

    /*
    This method is used to check wether the usertype entered by the user in the login page matches their Login details. 
    The method fetches the the username(parameter) from the login page and uses a sql query to compare the username entered
    to what usertype they said they are. If the username entered exists and the logintype matches,
    the boolean value of the method is set to true which allows the user to preceed 
    to the next page. There is a catch statement if the database doesn't respond to the query
     */
    public boolean isValidUsertype(String loginType) {
        boolean let_in = false;

        ResultSet rs = getResults("SELECT * FROM UserSpecs WHERE UsernameLogin ='" + username + "'");

        try {

            if (rs.next()) {
                if (rs.getString("loginType").equals(loginType)) {
                    return true;

                }
                System.out.println("loginType answer" + let_in);
            }
        } catch (SQLException ex) {
            System.out.println("Error with result set:" + ex);
        }

        return let_in;
    }

    /*
    The parameter of the method is a colour. The seat colour is read in on a different class and if the colour of that GUI button
    matches the given collour then availibity is set true and if it doesnt match then the seat isnt available.
     */
    public boolean isAvailable(String color) {
        boolean Available = false;

        if (color.equals("-fx-background-color: #01579B;")) {
            return true;
        } else {
            return false;
        }
    }

    //declaring getters and setters which are used to transport information between classes and backend
    public String getUsername() {
        return username;
    }
//this set method has a String username parameter

    public void setUsername(String username) {
        System.out.println("In classs: " + username);
        this.username = username;
    }

    public int getCount() {
        return count;
    }
//this set method has a int count parameter

    public void setCount(int count) {
        SQLBackend.count = count;
    }
//this set method has a String usertype parameter

    public void setUsertype(String usertype) {
        this.usertype = usertype;
        System.out.println("Usertype set to " + usertype);
    }

    public String getUsertype() {
        return usertype;
    }

    /*
    This method has the parameter productionName which is used to fetch informtion on what production the tickets are for. The method uses the 
    given production and then uses and sql query to read off the productions ticket price which is returned as value. If there is a faulty result 
    set or there is an exception with it then a catch method is run
     */
    public String ticketPriceCheck(String productionName) {

        ResultSet qt = getResults("SELECT ticketPrice FROM ProductionSpecs WHERE productionName ='" + productionName + "'");
        String value = "";
        try {
            if (qt.next()) {
                value = qt.getString("ticketPrice");
                return value;

            } else {
                System.out.println("ticketPrice amount found");
            }
        } catch (SQLException ex) {
            System.out.println("Error with result set:" + ex);
        }
        return value;
    }

    //more getters and setters are declared
    public String getProductionName() {
        return productionName;
    }

    // set method has String productionName
    public void setProductionName(String productionName) {
        SQLBackend.productionName = productionName;
    }

    public String getSeatLetter() {
        return seatLetter;
    }

    //has parameter String seatLetter
    public void setSeatLetter(String seatLetter) {
        SQLBackend.seatLetter = seatLetter;

    }

    public int getSeatNumber() {
        return seatNumber;
    }

    //has parameter Int seatnumber
    public void setSeatNumber(int seatNumber) {
        SQLBackend.seatNumber = seatNumber;
    }

    /*
    This method updates the seats availability. The method starts by fetching the row letter and number with getters and setters to make up a seat.
    The seat is then updated with an update sql query where the seat is updated to unavailable and the users userID is etched and added to the 
    update stament and therefor the database in order to keep track of who booked the seat
   
     */
    public String updateSeating() {
        try {
            String seat = this.getSeatLetter() + this.getSeatNumber();

            //System.out.println("UPDATE SeatingTable SET Available = False, UserID = '"+this.getUsername()+"' WHERE Production ='" + this.getProductionName() + "' AND seatLetter = '" + this.getSeatLetter() + "' AND seatNumber = " + this.getSeatNumber() + "");
            //Update("UPDATE SeatingTable SET Available = False WHERE Production ='" + this.getProductionName() + "' AND seatLetter = '" + this.getSeatLetter() + "' AND seatNumber = " + this.getSeatNumber() + "");
            System.out.println(("UPDATE SeatingTable SET Available = FALSE, UserID = ( select UserID FROM UserSpecs Where usernameLogin like'" + this.getUsername() + "')  WHERE Production ='" + this.getProductionName() + "' AND seatLetter = '" + this.getSeatLetter() + "' AND seatNumber = '" + this.getSeatNumber() + "'"));
            ResultSet rs = getResults("SELECT UserID FROM UserSpecs WHERE usernameLogin like '" + this.getUsername() + "'");
            rs.next();
            int userID = rs.getInt("UserID");
            Update("UPDATE SeatingTable SET Available = FALSE, UserID = " + userID + " WHERE Production ='" + this.getProductionName() + "' AND seatLetter = '" + this.getSeatLetter() + "' AND seatNumber = '" + this.getSeatNumber() + "'");
            System.out.println("seat updated " + seat);

        } catch (SQLException ex) {
            Logger.getLogger(SQLBackend.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    /*
    This method has the parameters production and seat. The method runs through the seating results for the given proudction and returns 
    if the seat is available or not .The seating availability is checked via a sql query. There is a catch method if the result set has an error
     */
    public boolean IsSeatAvailable(String production, String seat) { //used to changed GUI Colour for next user, if colour is changed previous methods prevent it from being clicked
        //not working because i cant view my databade and i think all seats have been updated to not available

        ResultSet qt = getResults("SELECT Available FROM SeatingTable WHERE Production ='" + production + "' AND seatLetter = '" + seat.charAt(0) + "' AND seatNumber = " + seat.charAt(1) + "");

        try {
            if (qt.next()) {
                return qt.getBoolean("Available");
            } else {
                System.out.println("Seat not found");
                return false;
            }
        } catch (SQLException ex) {
            System.out.println("Error with result set:" + ex);
        }
        return false;
    }

    /*
   This method has the parameter bookersname(Used in place of UserId), production and seat. 
   The method fetches the production that is being worked with and the seat that needs to be updated.
   The seat runs an update query that changes the availability status of a seat to unavailable and enters the name of whoever booked the seat.
     */
    public boolean makeUnAvailable(String bookersname, String Production, String seat) {

        System.out.println("UPDATE SeatingTable SET Available = False AND UserID = '" + bookersname + "' WHERE Production ='" + Production + "' AND seatLetter = '" + seat.charAt(0) + "' AND seatNumber = " + seat.charAt(1) + "");
        Update("UPDATE SeatingTable SET Available = FALSE AND UserID = 0 WHERE Production ='" + Production + "' AND seatLetter = '" + seat.charAt(0) + "' AND seatNumber = " + seat.charAt(1) + "");

        System.out.println("seat updated " + seat);

        return true;
    }

    /*
  This method has the parameter production and seat. The method fetches the production that is being worked with and the seat 
  that needs to be updated. The seat runs an update query that changes the availability status of a seat to Available. 
  This method is used in the admin screen
     */
    public boolean makeAvailable(String Production, String seat) {
        System.out.println("UPDATE SeatingTable SET Available = TRUE WHERE Production ='" + Production + "' AND seatLetter = '" + seat.charAt(0) + "' AND seatNumber = " + seat.charAt(1) + "");
        Update("UPDATE SeatingTable SET Available = TRUE WHERE Production ='" + Production + "' AND seatLetter = '" + seat.charAt(0) + "' AND seatNumber = " + seat.charAt(1) + "");

        System.out.println("seat updated " + seat);

        return true;
    }

    /*
       This method is used to read out the name via an sql select query of whoever booked a seat for the given production that is fetched by the
       method. The output is then transported to the admin class and is displayed to the right of the cursor/gui button.
     */
    public String tooltipName(String Production) { //gets name that displayed on admin page when cursor hovers over seat

        ResultSet qt = getResults("SELECT UserID FROM SeatingTable WHERE Production ='" + Production + "' AND seatLetter = '" + this.getSeatLetter() + "' AND seatNumber = " + this.getSeatNumber() + "");
        String value = "";
        try {
            if (qt.next()) {
                value = qt.getString("UserID");
                return value;

            } else {
                System.out.println("UserID amount found");
            }
        } catch (SQLException ex) {
            System.out.println("Error with result set:" + ex);
        }
        return value;
    }
}
